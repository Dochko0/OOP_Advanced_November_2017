package cresla.models.moduls;

public class CooldownSystem extends AbstractAbsorbingModule{

    public CooldownSystem(int id, int property) {
        super(id, property);
    }
}
