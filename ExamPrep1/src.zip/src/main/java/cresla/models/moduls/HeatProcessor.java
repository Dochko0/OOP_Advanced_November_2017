package cresla.models.moduls;

import cresla.interfaces.AbsorbingModule;

public class HeatProcessor extends AbstractAbsorbingModule{


    public HeatProcessor(int id, int property) {
        super(id, property);
    }
}
