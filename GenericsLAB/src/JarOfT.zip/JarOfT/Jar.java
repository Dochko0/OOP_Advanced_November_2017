package JarOfT;

import java.util.ArrayDeque;
import java.util.Deque;

class Jar<E> {
    private Deque<E> content= new ArrayDeque<>();

    void add(E element){
        content.push(element);
    }

    E remove(){
     return this.content.pop();
    }
}
