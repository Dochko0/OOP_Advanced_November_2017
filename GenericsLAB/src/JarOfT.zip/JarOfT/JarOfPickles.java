package JarOfT;

public class JarOfPickles extends Jar<Pickle> {
}
