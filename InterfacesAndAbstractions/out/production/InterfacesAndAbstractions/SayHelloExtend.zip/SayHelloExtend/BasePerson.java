package SayHelloExtend;

public abstract class BasePerson implements Person{
    private String name;

    BasePerson(String name) {
        setName(name);
    }

    public String getName() {
        return this.name;
    }

    @Override
    public String sayHello() {
        return null;
    }

    private void setName(String name) {
        this.name = name;
    }
}
